# Orchestrator Memory

## Active State

- wave: Agent Workflow Simplification Wave 1 — all slices complete
- plan: `docs/agents/lead-strategic/current_plan.md`
- branch: `feature/agent-workflow-simplification-wave1`
- status: ready for wave closure review and commit
- profile: mixed-claude-workers

## Pruning Rule

On new wave: rewrite this file, don't append. Keep only active state and resume point. Closed-wave detail belongs in last_report.md, archive, or git log.
