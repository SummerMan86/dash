# Lead-Strategic Memory

## Active State

- wave: Agent Workflow Simplification Wave 1 — all slices complete, pending closure
- plan: `docs/agents/lead-strategic/current_plan.md`
- branch: `feature/agent-workflow-simplification-wave1`
- status: awaiting wave closure review and commit

## Still-Valid Decisions

- `lead-strategic` owns planning and acceptance
- `orchestrator` owns execution flow, not product-code implementation
- `direct-fix` remains narrow
- truthful evidence and minimum independent review floor survive wording changes
- `mixed-claude-workers` is the practical default

## Pruning Rule

On new wave: rewrite this file, don't append. Keep only active state and still-valid decisions. Closed-wave detail belongs in last_report.md, archive, or git log.
